'use client'

import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Plus, Edit, Trash2, CheckCircle, DollarSign, TrendingUp, TrendingDown, Download, Upload } from 'lucide-react'

interface Option {
  id: string
  name: string
  price: number
  advantages: string
  disadvantages: string
}

interface Selection {
  id: string
  title: string
  description?: string
  options: Option[]
  finalChoice?: {
    optionId: string
    reason?: string
  }
}

const STORAGE_KEY = 'price-comparison-data'

export default function PriceComparisonApp() {
  const [selections, setSelections] = useState<Selection[]>([])
  const [currentSelection, setCurrentSelection] = useState<Selection | null>(null)
  const [isAddingSelection, setIsAddingSelection] = useState(false)
  const [newSelectionTitle, setNewSelectionTitle] = useState('')
  const [newSelectionDescription, setNewSelectionDescription] = useState('')
  const [isAddingOption, setIsAddingOption] = useState(false)
  const [newOption, setNewOption] = useState({
    name: '',
    price: 0,
    advantages: '',
    disadvantages: ''
  })

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY)
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData)
        setSelections(parsed.selections || [])
        setCurrentSelection(parsed.currentSelection || null)
      } catch (error) {
        console.error('Error loading data from localStorage:', error)
      }
    }
  }, [])

  // Save data to localStorage whenever data changes
  useEffect(() => {
    const dataToSave = {
      selections,
      currentSelection
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave))
  }, [selections, currentSelection])

  const addSelection = () => {
    if (!newSelectionTitle.trim()) return
    
    const selection: Selection = {
      id: Date.now().toString(),
      title: newSelectionTitle,
      description: newSelectionDescription,
      options: []
    }
    
    setSelections([...selections, selection])
    setCurrentSelection(selection)
    setNewSelectionTitle('')
    setNewSelectionDescription('')
    setIsAddingSelection(false)
  }

  const addOption = () => {
    if (!currentSelection || !newOption.name.trim()) return
    
    const option: Option = {
      id: Date.now().toString(),
      name: newOption.name,
      price: newOption.price,
      advantages: newOption.advantages,
      disadvantages: newOption.disadvantages
    }
    
    const updatedSelection = {
      ...currentSelection,
      options: [...currentSelection.options, option]
    }
    
    setCurrentSelection(updatedSelection)
    setSelections(selections.map(s => s.id === currentSelection.id ? updatedSelection : s))
    
    setNewOption({ name: '', price: 0, advantages: '', disadvantages: '' })
    setIsAddingOption(false)
  }

  const deleteOption = (optionId: string) => {
    if (!currentSelection) return
    
    const updatedSelection = {
      ...currentSelection,
      options: currentSelection.options.filter(opt => opt.id !== optionId),
      finalChoice: currentSelection.finalChoice?.optionId === optionId ? undefined : currentSelection.finalChoice
    }
    
    setCurrentSelection(updatedSelection)
    setSelections(selections.map(s => s.id === currentSelection.id ? updatedSelection : s))
  }

  const selectFinalChoice = (optionId: string, reason?: string) => {
    if (!currentSelection) return
    
    const updatedSelection = {
      ...currentSelection,
      finalChoice: { optionId, reason }
    }
    
    setCurrentSelection(updatedSelection)
    setSelections(selections.map(s => s.id === currentSelection.id ? updatedSelection : s))
  }

  const deleteSelection = (selectionId: string) => {
    const updatedSelections = selections.filter(s => s.id !== selectionId)
    setSelections(updatedSelections)
    if (currentSelection?.id === selectionId) {
      setCurrentSelection(updatedSelections[0] || null)
    }
  }

  const getMinPrice = () => {
    if (!currentSelection || currentSelection.options.length === 0) return 0
    return Math.min(...currentSelection.options.map(opt => opt.price))
  }

  const getMaxPrice = () => {
    if (!currentSelection || currentSelection.options.length === 0) return 0
    return Math.max(...currentSelection.options.map(opt => opt.price))
  }

  const exportData = () => {
    const data = {
      selections,
      exportDate: new Date().toISOString(),
      version: '1.0'
    }
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `price-comparison-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string)
        if (data.selections && Array.isArray(data.selections)) {
          setSelections(data.selections)
          setCurrentSelection(data.selections[0] || null)
          alert('Data berhasil diimpor!')
        } else {
          alert('Format file tidak valid!')
        }
      } catch (error) {
        alert('Error membaca file!')
      }
    }
    reader.readAsText(file)
    // Reset input
    event.target.value = ''
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-center mb-2">Aplikasi Perbandingan Harga & Evaluasi Vendor</h1>
          <p className="text-muted-foreground text-center">Bandingkan harga dan evaluasi vendor/pemangku kepentingan dengan mudah</p>
          <div className="flex justify-center gap-4 mt-4">
            <Button onClick={exportData} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            <label htmlFor="import-data">
              <Button variant="outline" size="sm" asChild>
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  Import Data
                </span>
              </Button>
            </label>
            <input
              id="import-data"
              type="file"
              accept=".json"
              onChange={importData}
              className="hidden"
            />
          </div>
        </div>

        <Tabs defaultValue="input" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="input">Input Data</TabsTrigger>
            <TabsTrigger value="comparison">Perbandingan & Analisis</TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="space-y-6">
            {/* Selection List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span>Daftar Pemilihan</span>
                  <Dialog open={isAddingSelection} onOpenChange={setIsAddingSelection}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Pemilihan Baru</DialogTitle>
                        <DialogDescription>
                          Buat judul pemilihan untuk memulai perbandingan
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="title">Judul Pemilihan</Label>
                          <Input
                            id="title"
                            value={newSelectionTitle}
                            onChange={(e) => setNewSelectionTitle(e.target.value)}
                            placeholder="Contoh: Pemilihan Vendor IT"
                          />
                        </div>
                        <div>
                          <Label htmlFor="description">Deskripsi (Opsional)</Label>
                          <Textarea
                            id="description"
                            value={newSelectionDescription}
                            onChange={(e) => setNewSelectionDescription(e.target.value)}
                            placeholder="Deskripsi singkat tentang pemilihan ini"
                          />
                        </div>
                        <Button onClick={addSelection} className="w-full">
                          Tambah Pemilihan
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {selections.map((selection) => (
                    <Card 
                      key={selection.id} 
                      className={`cursor-pointer transition-colors ${
                        currentSelection?.id === selection.id ? 'ring-2 ring-primary' : 'hover:bg-muted/50'
                      }`}
                      onClick={() => setCurrentSelection(selection)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-lg">{selection.title}</CardTitle>
                            {selection.description && (
                              <CardDescription>{selection.description}</CardDescription>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation()
                              if (confirm('Hapus pemilihan ini?')) {
                                deleteSelection(selection.id)
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">
                            {selection.options.length} pilihan
                          </span>
                          {selection.finalChoice && (
                            <Badge variant="default" className="text-xs">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Dipilih
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {selections.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    Belum ada data pemilihan. Klik tombol + untuk membuat pemilihan baru.
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Current Selection Details */}
            {currentSelection && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{currentSelection.title}</span>
                    <Dialog open={isAddingOption} onOpenChange={setIsAddingOption}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="h-4 w-4 mr-2" />
                          Tambah Pilihan
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Tambah Pilihan Baru</DialogTitle>
                          <DialogDescription>
                            Masukkan detail pilihan untuk perbandingan
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="optionName">Nama Pilihan</Label>
                            <Input
                              id="optionName"
                              value={newOption.name}
                              onChange={(e) => setNewOption({...newOption, name: e.target.value})}
                              placeholder="Contoh: Vendor A"
                            />
                          </div>
                          <div>
                            <Label htmlFor="optionPrice">Harga</Label>
                            <Input
                              id="optionPrice"
                              type="number"
                              value={newOption.price}
                              onChange={(e) => setNewOption({...newOption, price: parseFloat(e.target.value) || 0})}
                              placeholder="0"
                            />
                          </div>
                          <div>
                            <Label htmlFor="advantages">Kelebihan</Label>
                            <Textarea
                              id="advantages"
                              value={newOption.advantages}
                              onChange={(e) => setNewOption({...newOption, advantages: e.target.value})}
                              placeholder="Kelebihan dari pilihan ini"
                            />
                          </div>
                          <div>
                            <Label htmlFor="disadvantages">Kekurangan</Label>
                            <Textarea
                              id="disadvantages"
                              value={newOption.disadvantages}
                              onChange={(e) => setNewOption({...newOption, disadvantages: e.target.value})}
                              placeholder="Kekurangan dari pilihan ini"
                            />
                          </div>
                          <Button onClick={addOption} className="w-full">
                            Tambah Pilihan
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardTitle>
                  {currentSelection.description && (
                    <CardDescription>{currentSelection.description}</CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {currentSelection.options.map((option) => (
                      <Card key={option.id}>
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg flex items-center gap-2">
                              {option.name}
                              <Badge variant="secondary" className="text-xs">
                                <DollarSign className="h-3 w-3 mr-1" />
                                Rp {option.price.toLocaleString('id-ID')}
                              </Badge>
                              {currentSelection.finalChoice?.optionId === option.id && (
                                <Badge variant="default" className="text-xs">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Dipilih
                                </Badge>
                              )}
                            </CardTitle>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteOption(option.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium text-green-700 mb-2 flex items-center gap-1">
                                <TrendingUp className="h-4 w-4" />
                                Kelebihan
                              </h4>
                              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                                {option.advantages || 'Belum ada kelebihan'}
                              </p>
                            </div>
                            <div>
                              <h4 className="font-medium text-red-700 mb-2 flex items-center gap-1">
                                <TrendingDown className="h-4 w-4" />
                                Kekurangan
                              </h4>
                              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                                {option.disadvantages || 'Belum ada kekurangan'}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {currentSelection.options.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        Belum ada pilihan. Klik tombol "Tambah Pilihan" untuk memulai.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="comparison" className="space-y-6">
            {currentSelection ? (
              <>
                {/* Price Comparison Table */}
                <Card>
                  <CardHeader>
                    <CardTitle>Tabel Perbandingan Harga</CardTitle>
                    <CardDescription>
                      Perbandingan harga antar pilihan untuk {currentSelection.title}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Pilihan</TableHead>
                          <TableHead className="text-right">Harga</TableHead>
                          <TableHead className="text-right">Perbandingan</TableHead>
                          <TableHead>Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentSelection.options.map((option) => {
                          const minPrice = getMinPrice()
                          const maxPrice = getMaxPrice()
                          
                          return (
                            <TableRow key={option.id}>
                              <TableCell className="font-medium">{option.name}</TableCell>
                              <TableCell className="text-right">
                                Rp {option.price.toLocaleString('id-ID')}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-2">
                                  {option.price === minPrice && (
                                    <Badge variant="default" className="text-xs">
                                      Termurah
                                    </Badge>
                                  )}
                                  {option.price === maxPrice && option.price !== minPrice && (
                                    <Badge variant="destructive" className="text-xs">
                                      Termahal
                                    </Badge>
                                  )}
                                  {option.price > minPrice && (
                                    <span className="text-sm text-muted-foreground">
                                      +Rp {(option.price - minPrice).toLocaleString('id-ID')}
                                    </span>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  variant={currentSelection.finalChoice?.optionId === option.id ? "default" : "outline"}
                                  onClick={() => {
                                    if (currentSelection.finalChoice?.optionId === option.id) {
                                      // Remove selection
                                      const updatedSelection = {
                                        ...currentSelection,
                                        finalChoice: undefined
                                      }
                                      setCurrentSelection(updatedSelection)
                                      setSelections(selections.map(s => s.id === currentSelection.id ? updatedSelection : s))
                                    } else {
                                      const reason = prompt('Alasan pemilihan ini (opsional):')
                                      selectFinalChoice(option.id, reason || undefined)
                                    }
                                  }}
                                >
                                  {currentSelection.finalChoice?.optionId === option.id ? 'Terpilih' : 'Pilih'}
                                </Button>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                {/* Advantages/Disadvantages Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Ringkasan Keuntungan & Kerugian</CardTitle>
                    <CardDescription>
                      Analisis kelebihan dan kekurangan setiap pilihan
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6">
                      {currentSelection.options.map((option) => (
                        <div key={option.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold flex items-center gap-2">
                              {option.name}
                              <Badge variant="outline">
                                Rp {option.price.toLocaleString('id-ID')}
                              </Badge>
                              {currentSelection.finalChoice?.optionId === option.id && (
                                <Badge variant="default" className="text-xs">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Pilihan Terbaik
                                </Badge>
                              )}
                            </h3>
                          </div>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                              <h4 className="font-medium text-green-800 mb-2 flex items-center gap-1">
                                <TrendingUp className="h-4 w-4" />
                                Kelebihan
                              </h4>
                              <p className="text-sm text-green-700 whitespace-pre-wrap">
                                {option.advantages || 'Tidak ada kelebihan yang tercantum'}
                              </p>
                            </div>
                            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                              <h4 className="font-medium text-red-800 mb-2 flex items-center gap-1">
                                <TrendingDown className="h-4 w-4" />
                                Kekurangan
                              </h4>
                              <p className="text-sm text-red-700 whitespace-pre-wrap">
                                {option.disadvantages || 'Tidak ada kekurangan yang tercantum'}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Final Selection */}
                {currentSelection.finalChoice && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5" />
                        Kesimpulan Akhir
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-lg font-semibold">
                            Pilihan Terbaik: {
                              currentSelection.options.find(opt => opt.id === currentSelection.finalChoice?.optionId)?.name
                            }
                          </h3>
                          <Badge variant="default">
                            Rp {currentSelection.options.find(opt => opt.id === currentSelection.finalChoice?.optionId)?.price.toLocaleString('id-ID')}
                          </Badge>
                        </div>
                        {currentSelection.finalChoice.reason && (
                          <div>
                            <h4 className="font-medium mb-2">Alasan Pemilihan:</h4>
                            <p className="text-muted-foreground">{currentSelection.finalChoice.reason}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="text-center space-y-2">
                    <h3 className="text-lg font-semibold">Belum ada data pemilihan</h3>
                    <p className="text-muted-foreground">
                      Silakan buat pemilihan terlebih dahulu di tab Input Data
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}