# Aplikasi Perbandingan Harga & Evaluasi Vendor (Static Version)

Aplikasi web statis untuk membandingkan harga dan mengevaluasi vendor/pemangku kepentingan. Dibangun dengan Next.js, TypeScript, dan Tailwind CSS. Versi ini dapat dihosting di GitHub Pages.

## 🚀 Fitur Utama

### ✅ Input Data Master
- **Judul Pemilihan** - Buat judul untuk setiap sesi perbandingan
- **Master Pilihan** - Tambahkan Pilihan1, Pilihan2, Pilihan3, dst.
- **Input Kelebihan & Kekurangan** - Form lengkap untuk setiap pilihan

### ✅ Fungsi Utama
- **Perbandingan Harga** - Tabel interaktif dengan indikator visual
- **Ringkasan Keuntungan & Kerugian** - Tampilan terstruktur
- **Dasbor Interaktif** - Antarmuka yang mudah digunakan
- **Kesimpulan Akhir** - Pemilihan opsi terbaik dengan alasan

### ✅ Fitur Tambahan
- **Data Persistence** - Menggunakan localStorage browser
- **Export/Import Data** - Backup dan restore data dalam format JSON
- **Responsive Design** - Bisa digunakan di desktop dan mobile
- **No Backend Required** - Berjalan sepenuhnya di client-side

## 🛠️ Teknologi

- **Frontend**: Next.js 15, TypeScript, React 19
- **Styling**: Tailwind CSS 4, shadcn/ui components
- **Icons**: Lucide React
- **Storage**: Browser localStorage
- **Deployment**: GitHub Pages (static hosting)

## 📦 Instalasi & Development

### Prasyarat
- Node.js 18+ 
- npm atau yarn

### Instalasi
```bash
# Clone repository
git clone https://github.com/username/price-comparison-app.git
cd price-comparison-app

# Install dependencies
npm install

# Run development server
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) untuk melihat aplikasi.

## 🚀 Deploy ke GitHub Pages

### Langkah 1: Build untuk Production
```bash
# Build static export
npm run export
```

### Langkah 2: Push ke GitHub
```bash
# Inisialisasi git (jika belum)
git init
git add .
git commit -m "Initial commit: Static price comparison app"

# Tambahkan remote repository
git remote add origin https://github.com/USERNAME/price-comparison-app.git
git branch -M main
git push -u origin main
```

### Langkah 3: Setup GitHub Pages

#### Opsi A: Menggunakan GitHub Actions (Recommended)

1. **Buat file workflow:**
   ```bash
   mkdir -p .github/workflows
   ```

2. **Buat file `deploy.yml`:**
   ```yaml
   name: Deploy to GitHub Pages
   
   on:
     push:
       branches: [ main ]
     pull_request:
       branches: [ main ]
   
   jobs:
     deploy:
       runs-on: ubuntu-latest
       
       steps:
       - name: Checkout
         uses: actions/checkout@v4
         
       - name: Setup Node.js
         uses: actions/setup-node@v4
         with:
           node-version: '18'
           cache: 'npm'
           
       - name: Install dependencies
         run: npm install
         
       - name: Build and Export
         run: npm run export
         
       - name: Deploy to GitHub Pages
         uses: peaceiris/actions-gh-pages@v3
         if: github.ref == 'refs/heads/main'
         with:
           github_token: ${{ secrets.GITHUB_TOKEN }}
           publish_dir: ./out
   ```

3. **Commit dan push:**
   ```bash
   git add .github/workflows/deploy.yml
   git commit -m "Add GitHub Actions deployment"
   git push origin main
   ```

#### Opsi B: Manual Deployment

1. **Build project:**
   ```bash
   npm run export
   ```

2. **Buat gh-pages branch:**
   ```bash
   git checkout --orphan gh-pages
   git --work-tree=out add --all
   git commit -m "Deploy to GitHub Pages"
   git push origin gh-pages
   ```

3. **Setup GitHub Pages:**
   - Buka repository GitHub
   - Go to Settings → Pages
   - Source: Deploy from a branch
   - Branch: gh-pages
   - Folder: / (root)
   - Save

### Langkah 4: Akses Aplikasi

Aplikasi akan tersedia di:
```
https://USERNAME.github.io/price-comparison-app/
```

## 📱 Cara Penggunaan

### 1. **Membuat Pemilihan Baru**
- Klik tombol "+" di "Daftar Pemilihan"
- Isi judul dan deskripsi (opsional)
- Klik "Tambah Pemilihan"

### 2. **Menambahkan Pilihan**
- Klik pada judul pemilihan yang sudah dibuat
- Klik "Tambah Pilihan"
- Isi nama pilihan, harga, kelebihan, dan kekurangan
- Klik "Tambah Pilihan"

### 3. **Melihat Perbandingan**
- Pindah ke tab "Perbandingan & Analisis"
- Lihat tabel perbandingan harga
- Analisis keuntungan dan kerugian
- Pilih opsi terbaik dengan mengklik tombol "Pilih"

### 4. **Export/Import Data**
- **Export**: Klik "Export Data" untuk download backup
- **Import**: Klik "Import Data" untuk upload backup file

## 🎨 Customization

### Mengubah Warna Tema
Edit file `tailwind.config.ts` untuk mengubah warna default:

```typescript
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          500: '#3b82f6',
          // ... tambahkan warna lain
        }
      }
    }
  }
}
```

### Menambahkan Fitur
- Edit file `src/app/page.tsx` untuk menambahkan fitur baru
- Tambahkan komponen baru di `src/components/ui/`
- Update styles di `src/app/globals.css`

## 🔧 Troubleshooting

### Build Error
```bash
# Clear cache dan rebuild
rm -rf .next out
npm run export
```

### GitHub Pages Deployment Issues
1. Pastikan branch `gh-pages` sudah ada
2. Check GitHub Pages settings di repository
3. Pastikan file `index.html` ada di root folder

### LocalStorage Issues
- Data tersimpan di browser masing-masing user
- Data akan hilang jika browser cache dibersihkan
- Gunakan fitur export untuk backup data

## 📄 Lisensi

MIT License - lihat file [LICENSE](LICENSE) untuk detail

## 🤝 Kontribusi

1. Fork repository
2. Buat branch feature (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📞 Support

Jika ada masalah atau pertanyaan:
- Open issue di [GitHub Issues](https://github.com/USERNAME/price-comparison-app/issues)
- Email: your-email@example.com

---

**Built with ❤️ using Next.js and Tailwind CSS**